import os
import logging
import boto3
from datetime import datetime, timezone
import uuid
import json

import requests

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    Generates two pre-signed URLs and posts a message with both links
    to a Microsoft Teams channel via an Incoming Webhook.
    
    Environment Variables:
      - TARGET_BUCKET: Name of the S3 bucket where files are stored.
      - TEAMS_WEBHOOK_URL: Webhook URL for the Microsoft Teams channel.
    
    Returns:
      dict: A dictionary containing the status, video_url, project_url, 
            keys used or an error message.
    """
    bucket = os.environ.get("TARGET_BUCKET")
    if not bucket:
        error_msg = "TARGET_BUCKET environment variable not set."
        logger.error(error_msg)
        return {"error": error_msg}

    teams_webhook_url = os.environ.get("TEAMS_WEBHOOK_URL")
    if not teams_webhook_url:
        error_msg = "TEAMS_WEBHOOK_URL environment variable not set."
        logger.error(error_msg)
        return {"error": error_msg}

    s3 = boto3.client("s3")

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    unique_id = uuid.uuid4().hex
    video_key = f"anime_post_{timestamp}_{unique_id}.mp4"
    project_key = f"exports/anime_template_exported_{timestamp}_{unique_id}.aep"

    try:
        video_url = s3.generate_presigned_url(
            "get_object",
            Params={"Bucket": bucket, "Key": video_key},
            ExpiresIn=604800 
        )
    except Exception as e:
        logger.exception("Error generating presigned URL for video file: %s", e)
        return {"error": "Failed to generate presigned URL for video file."}

    try:
        project_url = s3.generate_presigned_url(
            "get_object",
            Params={"Bucket": bucket, "Key": project_key},
            ExpiresIn=604800
        )
    except Exception as e:
        logger.exception("Error generating presigned URL for project file: %s", e)
        return {"error": "Failed to generate presigned URL for project file."}

    message_text = (
        f"Your new post has been processed!\n\n"
        f"**Video URL**: {video_url}\n\n"
        f"**After Effects Project URL**: {project_url}"
    )

    teams_payload = {
        "text": message_text 
    }

    try:
        response = requests.post(
            teams_webhook_url,
            headers={"Content-Type": "application/json"},
            data=json.dumps(teams_payload)
        )
        response.raise_for_status()
    except Exception as e:
        logger.exception("Error posting message to Microsoft Teams: %s", e)
        return {"error": "Failed to post to Microsoft Teams channel."}

    logger.info("Message posted to Microsoft Teams successfully.")
    return {
        "status": "message_posted",
        "video_url": video_url,
        "project_url": project_url,
        "video_key": video_key,
        "project_key": project_key
    }
